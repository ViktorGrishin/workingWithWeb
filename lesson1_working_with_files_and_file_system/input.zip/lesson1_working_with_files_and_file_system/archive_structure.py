# from zipfile import ZipFile
#
# with ZipFile('input.zip') as archive:
#     dirs = archive.infolist()
#     print(dirs)
#


import shutil
shutil.make_archive('archive', 'zip', root_dir=r'C:\Users\vitya\Desktop\Vitya\Programming\yandex_lyceum\industrial_programming\workingWithWeb')